/* C2C Fix Pack v1 — 2025-09-20 */
(function(){
  // 1) Hamburger toggle (works with many common class/id names)
  const btn = document.querySelector('[data-nav-toggle], .hamburger, .menu-toggle, #menu-toggle, button[aria-label="Menu"]');
  const menu = document.querySelector('[data-nav], nav .nav-menu, #nav, #mobile-menu, .nav-menu');
  if(btn && menu){
    if(!menu.id) menu.id = 'c2c-nav';
    btn.setAttribute('aria-controls', menu.id);
    btn.addEventListener('click', function(e){
      e.preventDefault();
      const open = menu.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    }, {passive:false});
  }

  // 2) Force navigation to Stripe Payment Links even if other scripts interfere
  function go(href){ if(!href) return; window.location.assign(href); }
  document.addEventListener('click', function(e){
    const a = e.target.closest && e.target.closest('a[href^="https://buy.stripe.com"]');
    if(a){
      e.preventDefault(); e.stopPropagation();
      go(a.href);
    }
  }, true); // capture so we beat rogue handlers

  // 3) Keyboard accessibility for focused Stripe links
  document.addEventListener('keydown', function(e){
    if(e.key !== 'Enter' && e.key !== ' ') return;
    const el = document.activeElement;
    if(!el) return;
    const a = el.closest && el.closest('a[href^="https://buy.stripe.com"]');
    if(a){
      e.preventDefault(); e.stopPropagation();
      go(a.href);
    }
  }, true);
})();
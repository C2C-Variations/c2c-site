// Cloudflare Pages Function: injects C2C Fix Pack into every HTML page.
// No edits to your existing pages required.
export async function onRequest(context) {
  const res = await context.next();
  const ct = res.headers.get("content-type") || "";
  if (!ct.includes("text/html")) return res;

  let html = await res.text();
  const cssTag = '<link rel="stylesheet" href="/assets/css/hotfix-mobile.css?v=20250920">';
  const jsTag  = '<script src="/assets/js/fixpack.js?v=20250920"></script>';

  if (!html.includes("hotfix-mobile.css")) {
    html = html.includes("</head>") ? html.replace("</head>", cssTag + "\n</head>") : cssTag + html;
  }
  if (!html.includes("fixpack.js")) {
    html = html.includes("</body>") ? html.replace("</body>", jsTag + "\n</body>") : html + jsTag;
  }

  const headers = new Headers(res.headers);
  headers.delete("content-length");
  return new Response(html, { status: res.status, headers });
}

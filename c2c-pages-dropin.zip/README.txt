C2C Pages Drop-in — 2025-09-20

WHAT THIS IS
- A no-edit drop-in for **Cloudflare Pages + GitHub**.
- The folder **functions/** injects the Fix Pack CSS/JS into every HTML page on the edge.
- Upload everything to your GitHub repo root. No need to open or edit any page.

FILES INCLUDED
- functions/[[path]].js         ← injects the Fix Pack automatically
- assets/css/hotfix-mobile.css  ← Fix: Stripe buttons & overlays
- assets/js/fixpack.js          ← Fix: hamburger toggle + force Stripe nav
- resources.html + assets/...   ← Resource Hub page + data + calculators
- thank-you.html, cancelled.html

HOW TO DEPLOY (GitHub web UI)
1) Download this ZIP and unzip it locally.
2) In GitHub, open your site repo → **Add file → Upload files**.
3) Drag the **functions/** folder, **assets/** folder, **downloads/** folder, and the files **resources.html**, **thank-you.html**, **cancelled.html** into the **repo root**. Commit to your live branch.
4) Cloudflare Pages will auto-deploy (Functions detected). Then in Cloudflare → **Caching → Purge Everything**.

VERIFY
- Visit your site on mobile:
  • Hamburger menu opens/closes.
  • Solo/Crew/Business **Monthly** buttons open Stripe checkout (no more jumping).
- Visit `/resources.html` → search, filters, calculators work.
- If you set Stripe "After payment → Redirect", `/thank-you.html` loads with the plan tag.

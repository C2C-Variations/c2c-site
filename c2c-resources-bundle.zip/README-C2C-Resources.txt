C2C — Resources Hub (drop‑in)
=================================

What this adds (exactly what we agreed in the threads):
• /resources page with Instant Generators (Claim Intake, Variation Agreement, VIC Plumbing Compliance).
• Downloadable templates (placeholder TXT files so nothing 404s — swap for your real PDFs later using same filenames).
• National quick links table (WorkSafe/WHS, BYDA, Building & Plumbing Commission, Energy Safe, EPA, Safe Work Aus, Standards, Councils, nearest hospital).
• Interactive Guides (First 24 hours claim, Variation flow, VIC plumbing flow).
• FAQs.
• All styles/scripts are scoped under .c2c-rh-* so nothing else on your site is touched.

Where to drop these files
-------------------------
1) Put **resources.html** in the web root of your site (same place as index.html).
2) Put the **assets/** folder at the same level (so you have assets/resources.css and assets/resources.js).
3) Put the **resources/Templates/** folder exactly as-is (so downloadable links work).
4) (Optional but recommended) Append the rule from _redirects-addition.txt to your existing _redirects file (or just copy _redirects-addition.txt to _redirects if you don’t already have one). Rule is: 
   /resources  /resources.html  200
   Cloudflare Pages understands Netlify-style _redirects.

Nav link
--------
Your existing header/footer are untouched. If your current top nav already includes “Resources”, it will just work.
If it doesn’t yet, adding a link is one safe, 1-line change in your header/footer markup:
   <a href="/resources">Resources</a>

That is optional — the page is directly reachable at /resources either way.

Deploy
------
• GitHub + Cloudflare Pages: commit these new files to your repo in the locations above (no changes to existing files needed). Cloudflare will auto‑build.
• Manual upload (Pages/Netlify): upload your full site including these new files (Pages expects a full folder upload).

